#!/usr/bin/env python3
"""Synthetic Besu QBFT block builder for proof-size / gas estimation.

Builds: header (London-style, 16 fields), BftExtraData(vanity, validators, vote, round, seals),
receipts trie (key = RLP(txIndex), value = TRIE_ROOT receipt encoding, bloom included),
MPT inclusion proof for one receipt, committed seals over keccak(header with seals stripped, round kept).
"""
import json, os, sys, random
import rlp
from rlp.sedes import big_endian_int, binary, Binary, CountableList
from eth_utils import keccak, to_checksum_address
from eth_keys import keys
from trie import HexaryTrie

random.seed(7)

def rb(n): return bytes(random.getrandbits(8) for _ in range(n))

def make_log(addr, ntopics, datalen):
    return [addr, [rb(32) for _ in range(ntopics)], rb(datalen)]

def bloom_for(logs):
    b = bytearray(256)
    for addr, topics, _ in logs:
        for v in [addr] + topics:
            h = keccak(v)
            for i in (0, 2, 4):
                bit = ((h[i] << 8) | h[i+1]) & 0x7ff
                b[255 - bit // 8] |= 1 << (bit % 8)
    return bytes(b)

def encode_receipt(status, cum_gas, logs, tx_type):
    body = rlp.encode([status, cum_gas, bloom_for(logs), logs])
    return (bytes([tx_type]) + body) if tx_type else body

def int_be(i):
    return b"" if i == 0 else i.to_bytes((i.bit_length() + 7) // 8, "big")

def build(n_validators, n_tx, target_idx, n_logs, n_topics, data_len, tx_type=2, block_number=123456):
    # --- receipts trie
    receipts = []
    for i in range(n_tx):
        if i == target_idx:
            logs = [make_log(rb(20), n_topics, data_len) for _ in range(n_logs)]
        else:
            logs = [make_log(rb(20), 2, 32)]  # other txs: one small log
        receipts.append(encode_receipt(1, 21000 * (i + 1), logs, tx_type))
    t = HexaryTrie({})
    for i, r in enumerate(receipts):
        t[rlp.encode(i)] = r
    receipts_root = t.root_hash
    proof = t.get_proof(rlp.encode(target_idx))  # list of raw node bytes
    proof_nodes = [rlp.encode(n) for n in proof]

    # --- validators / keys
    pks = [keys.PrivateKey(rb(32)) for _ in range(n_validators)]
    validators = [pk.public_key.to_canonical_address() for pk in pks]
    quorum = -(-2 * n_validators // 3)  # ceil(2n/3)
    round_no = 0

    def extra(seals, rnd):
        vote = []  # no vote
        return rlp.encode([rb_vanity, validators, vote, rnd, seals])

    rb_vanity = bytes(32)
    def header_fields(extra_bytes):
        return [
            rb(32),            # parentHash
            keccak(rlp.encode([])),  # ommersHash
            validators[0],     # coinbase (proposer)
            rb(32),            # stateRoot
            rb(32),            # transactionsRoot
            receipts_root,     # receiptsRoot
            bloom_for([]),     # logsBloom (block-level; zeros here — real blocks OR all receipts)
            1,                 # difficulty (QBFT = 1)
            block_number,      # number
            30_000_000,        # gasLimit
            21000 * n_tx,      # gasUsed
            1_757_000_000,     # timestamp
            extra_bytes,       # extraData
            bytes(32),         # mixHash
            bytes(8),          # nonce
            7,                 # baseFeePerGas (London)
        ]
    # header w/ round kept, seals stripped -> commit seal hash
    h_strip = rlp.encode(header_fields(extra([], round_no)))
    seal_hash = keccak(h_strip)
    seals = [pks[i].sign_msg_hash(seal_hash).to_bytes() for i in range(quorum)]
    # header as stored on chain (full)
    h_full = rlp.encode(header_fields(extra(seals, round_no)))
    # onchain block hash (round=0, no seals)
    block_hash = keccak(rlp.encode(header_fields(extra([], 0))))

    # block-level bloom in real header would be OR of receipts blooms — make it realistic
    return {
        "n_validators": n_validators, "quorum": quorum, "n_tx": n_tx, "target_idx": target_idx,
        "headerStripped": "0x" + h_strip.hex(),
        "headerFull": "0x" + h_full.hex(),
        "seals": ["0x" + s.hex() for s in seals],
        "validators": [to_checksum_address(v) for v in validators],
        "validatorsHash": "0x" + keccak(b"".join(validators)).hex(),
        "receiptsRoot": "0x" + receipts_root.hex(),
        "sealHash": "0x" + seal_hash.hex(),
        "blockHash": "0x" + block_hash.hex(),
        "txIndex": target_idx,
        "logIndex": 0,
        "proof": ["0x" + p.hex() for p in proof_nodes],
        "receipt": "0x" + receipts[target_idx].hex(),
        "sizes": {
            "headerStripped": len(h_strip),
            "headerFull": len(h_full),
            "extraDataFull": len(extra(seals, round_no)),
            "seals": 65 * quorum,
            "proofNodes": [len(p) for p in proof_nodes],
            "proofTotal": sum(len(p) for p in proof_nodes),
            "receipt": len(receipts[target_idx]),
        },
    }

def calldata_gas(b: bytes):
    return sum(4 if x == 0 else 16 for x in b)

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "fixtures"
    os.makedirs(out, exist_ok=True)
    scenarios = {
        "v4_tx1":   dict(n_validators=4,  n_tx=1,   target_idx=0,  n_logs=1, n_topics=3, data_len=64),
        "v4_tx8":   dict(n_validators=4,  n_tx=8,   target_idx=5,  n_logs=1, n_topics=3, data_len=64),
        "v4_tx50":  dict(n_validators=4,  n_tx=50,  target_idx=37, n_logs=1, n_topics=3, data_len=64),
        "v4_tx200": dict(n_validators=4,  n_tx=200, target_idx=137,n_logs=1, n_topics=3, data_len=64),
        "v7_tx8":   dict(n_validators=7,  n_tx=8,   target_idx=5,  n_logs=1, n_topics=3, data_len=64),
        "v10_tx8":  dict(n_validators=10, n_tx=8,   target_idx=5,  n_logs=1, n_topics=3, data_len=64),
        "v16_tx8":  dict(n_validators=16, n_tx=8,   target_idx=5,  n_logs=1, n_topics=3, data_len=64),
        "v4_tx8_5logs": dict(n_validators=4, n_tx=8, target_idx=5, n_logs=5, n_topics=4, data_len=256),
    }
    summary = {}
    for name, kw in scenarios.items():
        fx = build(**kw)
        with open(f"{out}/{name}.json", "w") as f:
            json.dump(fx, f, indent=1)
        # payload bytes as the verifier would receive: headerStripped + seals + proof nodes (+ txIndex/logIndex scalars)
        payload = bytes.fromhex(fx["headerStripped"][2:]) + b"".join(bytes.fromhex(s[2:]) for s in fx["seals"]) \
                  + b"".join(bytes.fromhex(p[2:]) for p in fx["proof"])
        s = fx["sizes"]
        s["payloadRaw"] = len(payload)
        s["calldataGasRaw"] = calldata_gas(payload)
        summary[name] = {"quorum": fx["quorum"], **s}
        print(name, json.dumps(summary[name]))
    with open(f"{out}/summary.json", "w") as f:
        json.dump(summary, f, indent=1)
