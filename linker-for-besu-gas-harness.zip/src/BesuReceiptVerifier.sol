// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

/// @notice Prototype (estimation only): verify a Besu QBFT block header via committed seals,
///         then a receipt inclusion proof under receiptsRoot, and extract one log.
///         RLP walking is done on `bytes memory` with a minimal cursor-based reader.
contract BesuReceiptVerifier {
    bytes32 public validatorsHash; // keccak256(concat(validator addresses)) of the current set

    event Verified(bytes32 sealHash, bytes32 receiptsRoot, address emitter, uint256 topicsLen, uint256 dataLen);

    constructor(bytes32 vh) { validatorsHash = vh; }

    // ---------------------------------------------------------------- RLP
    // item at pos: returns (payloadOffset, payloadLength, isList)
    function _item(bytes memory b, uint256 pos) internal pure returns (uint256 off, uint256 len, bool isList) {
        uint8 p = uint8(b[pos]);
        if (p < 0x80) return (pos, 1, false);
        if (p < 0xb8) return (pos + 1, p - 0x80, false);
        if (p < 0xc0) {
            uint256 ll = p - 0xb7;
            uint256 l; for (uint256 i = 0; i < ll; i++) l = (l << 8) | uint8(b[pos + 1 + i]);
            return (pos + 1 + ll, l, false);
        }
        if (p < 0xf8) return (pos + 1, p - 0xc0, true);
        uint256 ll2 = p - 0xf7;
        uint256 l2; for (uint256 i = 0; i < ll2; i++) l2 = (l2 << 8) | uint8(b[pos + 1 + i]);
        return (pos + 1 + ll2, l2, true);
    }
    function _next(bytes memory b, uint256 pos) internal pure returns (uint256) {
        (uint256 off, uint256 len, ) = _item(b, pos);
        return off + len;
    }
    function _bytes32At(bytes memory b, uint256 off) internal pure returns (bytes32 r) {
        assembly { r := mload(add(add(b, 32), off)) }
    }
    function _slice(bytes memory b, uint256 off, uint256 len) internal pure returns (bytes memory r) {
        r = new bytes(len);
        assembly {
            let src := add(add(b, 32), off)
            let dst := add(r, 32)
            for { let i := 0 } lt(i, len) { i := add(i, 32) } { mstore(add(dst, i), mload(add(src, i))) }
        }
    }
    function _uintAt(bytes memory b, uint256 off, uint256 len) internal pure returns (uint256 v) {
        for (uint256 i = 0; i < len; i++) v = (v << 8) | uint8(b[off + i]);
    }

    // ---------------------------------------------------------------- header
    struct Hdr { bytes32 sealHash; bytes32 receiptsRoot; uint256 blockNumber; bytes validators; uint256 nv; }

    function _parseHeader(bytes memory h) internal view returns (Hdr memory H) {
        H.sealHash = keccak256(h);
        (uint256 off, , bool isList) = _item(h, 0);
        require(isList, "hdr");
        uint256 p = off;
        for (uint256 i = 0; i < 5; i++) p = _next(h, p);
        { (uint256 o, uint256 l, ) = _item(h, p); require(l == 32, "rr"); H.receiptsRoot = _bytes32At(h, o); }
        for (uint256 i = 5; i < 8; i++) p = _next(h, p);
        { (uint256 o, uint256 l, ) = _item(h, p); H.blockNumber = _uintAt(h, o, l); }
        for (uint256 i = 8; i < 12; i++) p = _next(h, p);
        (uint256 eo, uint256 el, ) = _item(h, p);           // extraData (bytes)
        (uint256 lo, , bool el_) = _item(h, eo); require(el_, "ed");
        uint256 q = _next(h, lo);                            // skip vanity
        (uint256 vo, uint256 vl, ) = _item(h, q);            // validators list
        uint256 nv; uint256 r = vo;
        while (r < vo + vl) { (uint256 ao, uint256 al, ) = _item(h, r); require(al == 20, "va"); nv++; r = ao + al; }
        bytes memory concat = new bytes(nv * 20);
        r = vo; uint256 k = 0;
        while (r < vo + vl) { (uint256 ao, , ) = _item(h, r); assembly { mcopy(add(add(concat, 32), k), add(add(h, 32), ao), 20) } k += 20; r = ao + 20; }
        require(keccak256(concat) == validatorsHash, "vset");
        H.validators = concat; H.nv = nv;
        q = _next(h, vo + vl);                               // vote
        q = _next(h, q);                                     // round (kept)
        (uint256 so, uint256 sl, bool sList) = _item(h, q);  // committed seals must be empty
        require(sList && sl == 0, "seals-not-stripped"); require(so + sl == eo + el, "ed-tail");
    }

    function _checkSeals(Hdr memory H, bytes[] calldata seals) internal pure {
        uint256 quorum = (2 * H.nv + 2) / 3;
        require(seals.length >= quorum, "quorum");
        uint256 seen; uint256 count; bytes memory concat = H.validators; bytes32 sealHash = H.sealHash;
        for (uint256 i = 0; i < seals.length; i++) {
            bytes calldata s = seals[i];
            require(s.length == 65, "sig");
            bytes32 r_; bytes32 s_; uint8 v_;
            assembly { r_ := calldataload(s.offset) s_ := calldataload(add(s.offset, 32)) v_ := byte(0, calldataload(add(s.offset, 64))) }
            if (v_ < 27) v_ += 27;
            address a = ecrecover(sealHash, v_, r_, s_);
            require(a != address(0), "ecr");
            uint256 idx = type(uint256).max;
            for (uint256 j = 0; j < H.nv; j++) {
                address c; assembly { c := shr(96, mload(add(add(concat, 32), mul(j, 20)))) }
                if (c == a) { idx = j; break; }
            }
            require(idx != type(uint256).max, "not-validator");
            require(seen & (1 << idx) == 0, "dup");
            seen |= (1 << idx); count++;
        }
        require(count >= quorum, "quorum2");
    }

    // ---------------------------------------------------------------- MPT
    function _nibbles(bytes memory key) internal pure returns (bytes memory n) {
        n = new bytes(key.length * 2);
        for (uint256 i = 0; i < key.length; i++) { n[2*i] = bytes1(uint8(key[i]) >> 4); n[2*i+1] = bytes1(uint8(key[i]) & 0x0f); }
    }
    function _rlpUint(uint256 x) internal pure returns (bytes memory) {
        if (x == 0) return hex"80";
        if (x < 0x80) return abi.encodePacked(uint8(x));
        uint256 len; uint256 t = x; while (t > 0) { len++; t >>= 8; }
        bytes memory r = new bytes(1 + len); r[0] = bytes1(uint8(0x80 + len));
        for (uint256 i = 0; i < len; i++) r[1 + i] = bytes1(uint8(x >> (8 * (len - 1 - i))));
        return r;
    }
    function _parseNode(bytes memory node) internal pure returns (uint256 cnt, uint256[17] memory offs, uint256[17] memory lens) {
        (uint256 off, uint256 len, bool isList) = _item(node, 0);
        require(isList, "node");
        uint256 p = off;
        while (p < off + len) { (uint256 o, uint256 l, ) = _item(node, p); offs[cnt] = o; lens[cnt] = l; cnt++; p = o + l; }
    }
    /// @dev consume hex-prefix encoded partial path; returns (isLeaf, new pi)
    function _matchPath(bytes memory node, uint256 o, uint256 l, bytes memory path, uint256 pi) internal pure returns (bool leaf, uint256) {
        uint8 flag = uint8(node[o]) >> 4;
        leaf = (flag & 2) != 0;
        uint256 skip = (flag & 1) != 0 ? 1 : 2;
        bytes memory enc = _nibbles(_slice(node, o, l));
        for (uint256 i = skip; i < enc.length; i++) { require(pi < path.length && enc[i] == path[pi], "path"); pi++; }
        return (leaf, pi);
    }
    /// @return value the leaf value (receipt encoding)
    function _verifyMPT(bytes32 root, uint256 txIndex, bytes[] calldata nodes) internal pure returns (bytes memory value) {
        bytes memory path = _nibbles(_rlpUint(txIndex));
        uint256 pi = 0;
        bytes32 want = root;
        for (uint256 ni = 0; ni < nodes.length; ni++) {
            bytes memory node = nodes[ni];
            require(keccak256(node) == want, "node-hash");
            (uint256 cnt, uint256[17] memory offs, uint256[17] memory lens) = _parseNode(node);
            if (cnt == 17) {
                if (pi == path.length) return _slice(node, offs[16], lens[16]);
                uint8 nib = uint8(path[pi]); pi++;
                require(lens[nib] == 32, "branch-child");
                want = _bytes32At(node, offs[nib]);
            } else if (cnt == 2) {
                bool leaf;
                (leaf, pi) = _matchPath(node, offs[0], lens[0], path, pi);
                if (leaf) { require(pi == path.length, "leaf-path"); return _slice(node, offs[1], lens[1]); }
                require(lens[1] == 32, "ext-child");
                want = _bytes32At(node, offs[1]);
            } else revert("node-shape");
        }
        revert("proof-short");
    }

    // ---------------------------------------------------------------- receipt
    function _extractLog(bytes memory receipt, uint256 logIndex)
        internal pure returns (address emitter, bytes32[] memory topics, bytes memory data)
    {
        uint256 start = 0;
        if (uint8(receipt[0]) < 0xc0) start = 1; // EIP-2718 typed receipt: type byte prefix
        (uint256 off, , bool isList) = _item(receipt, start); require(isList, "rcpt");
        uint256 p = off;
        p = _next(receipt, p); // status
        p = _next(receipt, p); // cumulativeGasUsed
        p = _next(receipt, p); // bloom
        (uint256 lo, uint256 ll, ) = _item(receipt, p); // logs
        uint256 q = lo; uint256 i = 0;
        while (q < lo + ll) {
            (uint256 o, uint256 l, ) = _item(receipt, q);
            if (i == logIndex) {
                uint256 r = o;
                { (uint256 ao, uint256 al, ) = _item(receipt, r); require(al == 20, "la"); emitter = address(uint160(uint256(_bytes32At(receipt, ao)) >> 96)); r = ao + al; }
                (uint256 to, uint256 tl, ) = _item(receipt, r);
                uint256 nt = 0; { uint256 s = to; while (s < to + tl) { s = _next(receipt, s); nt++; } }
                topics = new bytes32[](nt);
                { uint256 s = to; for (uint256 k = 0; k < nt; k++) { (uint256 xo, uint256 xl, ) = _item(receipt, s); require(xl == 32, "tp"); topics[k] = _bytes32At(receipt, xo); s = xo + xl; } }
                r = to + tl;
                (uint256 dOff, uint256 dl, ) = _item(receipt, r);
                data = _slice(receipt, dOff, dl);
                return (emitter, topics, data);
            }
            q = o + l; i++;
        }
        revert("log-index");
    }

    // ---------------------------------------------------------------- entry
    struct Proof { bytes headerStripped; bytes[] seals; uint256 txIndex; uint256 logIndex; bytes[] proofNodes; }
    struct LogOut { address emitter; bytes32[] topics; bytes data; }

    function verify(Proof calldata pf) external returns (LogOut memory out) {
        Hdr memory H = _parseHeader(pf.headerStripped);
        _checkSeals(H, pf.seals);
        bytes memory receipt = _verifyMPT(H.receiptsRoot, pf.txIndex, pf.proofNodes);
        (out.emitter, out.topics, out.data) = _extractLog(receipt, pf.logIndex);
        emit Verified(H.sealHash, H.receiptsRoot, out.emitter, out.topics.length, out.data.length);
    }
    function stages(Proof calldata pf) external view returns (uint256 gHeader, uint256 gSeals, uint256 gMpt, uint256 gLog) {
        uint256 g = gasleft();
        Hdr memory H = _parseHeader(pf.headerStripped); gHeader = g - gasleft(); g = gasleft();
        _checkSeals(H, pf.seals); gSeals = g - gasleft(); g = gasleft();
        bytes memory receipt = _verifyMPT(H.receiptsRoot, pf.txIndex, pf.proofNodes); gMpt = g - gasleft(); g = gasleft();
        _extractLog(receipt, pf.logIndex); gLog = g - gasleft();
    }
}
