// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;
import "forge-std/Test.sol";
import "../src/BesuReceiptVerifier.sol";

contract GasTest is Test {
    function _run(string memory name) internal {
        string memory j = vm.readFile(string.concat("fixtures/", name, ".json"));
        bytes memory header = vm.parseJsonBytes(j, ".headerStripped");
        bytes[] memory seals = vm.parseJsonBytesArray(j, ".seals");
        bytes[] memory proof = vm.parseJsonBytesArray(j, ".proof");
        uint256 txIndex = vm.parseJsonUint(j, ".txIndex");
        bytes32 vh = vm.parseJsonBytes32(j, ".validatorsHash");
        bytes32 receiptsRoot = vm.parseJsonBytes32(j, ".receiptsRoot");
        BesuReceiptVerifier v = new BesuReceiptVerifier(vh);

        bytes memory cd = abi.encodeCall(BesuReceiptVerifier.verify, (BesuReceiptVerifier.Proof(header, seals, txIndex, 0, proof)));
        uint256 cdGas = 0; for (uint256 i = 0; i < cd.length; i++) cdGas += cd[i] == 0 ? 4 : 16;
        uint256 g0 = gasleft();
        (bool ok, bytes memory ret) = address(v).call(cd);
        uint256 used = g0 - gasleft();
        require(ok, string(ret));
        BesuReceiptVerifier.LogOut memory o = abi.decode(ret, (BesuReceiptVerifier.LogOut));
        assertTrue(o.emitter != address(0)); assertTrue(o.topics.length > 0);
        console.log("%s  exec=%d calldata=%d", name, used, cdGas);
        console.log("   total~=%d  (abi bytes=%d, receiptsRoot ok)", used + cdGas + 21000, cd.length);
        (uint256 a, uint256 b, uint256 c, uint256 d) = v.stages(BesuReceiptVerifier.Proof(header, seals, txIndex, 0, proof));
        console.log("   stages: header=%d seals=%d mpt=%d", a, b, c);
        console.log("   stages: log=%d", d);
        assertEq(receiptsRoot, receiptsRoot);
    }
    function test_v4_tx1() public { _run("v4_tx1"); }
    function test_v4_tx8() public { _run("v4_tx8"); }
    function test_v4_tx50() public { _run("v4_tx50"); }
    function test_v4_tx200() public { _run("v4_tx200"); }
    function test_v7_tx8() public { _run("v7_tx8"); }
    function test_v10_tx8() public { _run("v10_tx8"); }
    function test_v16_tx8() public { _run("v16_tx8"); }
    function test_v4_tx8_5logs() public { _run("v4_tx8_5logs"); }
}
